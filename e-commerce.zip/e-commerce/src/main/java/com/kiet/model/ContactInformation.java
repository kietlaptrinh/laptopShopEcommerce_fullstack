package com.kiet.model;

import lombok.Data;

@Data
public class ContactInformation {
private String email;
private String mobile;
private String twitter;
private String facebook;   //instagram thay cho facebook
}
