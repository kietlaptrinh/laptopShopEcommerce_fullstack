package com.kiet.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Shop {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @OneToOne
    private User owner;
    private String name;
    private String description;
    //cuisineType trong web order food để mô tả loại ẩm thực của món ăn.
    //laptopType hoặc usageType trong web bán laptop để mô tả loại hoặc mục đích sử dụng của laptop.
    private String usageType;
    @OneToOne
    private Address address;
    @Embedded
    private ContactInformation contactInformation;
    private String supportHours; // Giờ hỗ trợ khách hàng của trang web bán laptop thay cho openingHours
    @OneToMany(mappedBy = "shop", cascade = CascadeType.ALL, orphanRemoval = true)

    private List<Order> orders = new ArrayList<>();
    @ElementCollection
    @Column(length = 1000)
    private List<String> images;
    private LocalDateTime registrationDate;
    private boolean active;//Sử dụng để biểu thị trạng thái của Hãng laptop, cho biết liệu Hãng laptop đó có đang hoạt động hay không.
    @JsonIgnore
    @OneToMany(mappedBy = "shop",cascade = CascadeType.ALL)
    private List<Laptop> laptops = new ArrayList<>();

}
