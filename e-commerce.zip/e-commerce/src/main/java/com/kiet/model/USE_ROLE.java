package com.kiet.model;


import jakarta.persistence.ManyToOne;

public enum USE_ROLE {
  ROLE_CUSTOMER,
  ROLE_SHOP_OWNER,
    ROLE_ADMIN

}
